# -*- coding: utf-8 -*-
"""
Created on Wed Feb  5 16:22:26 2020

@author: Grégoire
"""

import pandas as pd
import numpy as np
import csv
import scipy as sp
from scipy import stats
import statsmodels.api as sm
import statsmodels.formula.api as smf
import random
from rpy2 import robjects as R
from rpy2.robjects.packages import importr
from rpy2.robjects import pandas2ri, Formula
from rpy2.robjects.conversion import localconverter
pandas2ri.activate
rstatix = importr('rstatix', lib_loc='/home/loki/R/x86_64-pc-linux-gnu-library/4.1/')


class Between:
    def __init__(self, nb_participant, nb_exp, dataframe):
        self.nb_parti = nb_participant
        self.nb_exp = nb_exp
        self.df = dataframe
        #rstatix = importr('rstatix', lib_loc='/usr/local/lib/R/site-library')    


    def sampling(self, dataframe, sample_size):
        df_sampled = dataframe.sample(n = sample_size)
        return(df_sampled)

    def testing(self, vector1, vector2):
        #cat1 = dataframe[dataframe['Condition']=='Synchronous']
        #cat2 = dataframe[dataframe['Condition']=='Asynchronous']
        #z_df, p_df = stats.ttest_ind(cat1['value'], cat2['value'], nan_policy='omit')
        #t_df, p_df = stats.ttest_ind(dataframe['Synchronous'], dataframe['Asynchronous'], nan_policy='omit')
        z_df, p_df = sp.stats.mannwhitneyu(vector1, vector2)
        if(p_df < 0.05):
            bool = True
        else:
            bool = False
        return(p_df, bool)
    
    def get_Sync(self, dataframe):
        df_sync = dataframe[dataframe.Condition.str.contains('Synchronous', case=True)]
        return(df_sync)

    def get_Async(self, dataframe):
        df_async = dataframe[dataframe.Condition.str.contains('Asynchronous', case=True)]
        return(df_async)

    def get_Condition(self, dataframe, string):
        df_condition = dataframe[dataframe.Condition.str.contains(string, case=True)]
        return(df_condition)

    def writing_between(self, file_name, p_value_embo, confo, ef_size):
        with open(file_name, 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([self.nb_exp, int(self.nb_parti), p_value_embo, confo, ef_size])

    def effect_size(self, df_sync, df_async):
        #z_df, p_df = sp.stats.wilcoxon(dataframe['Synchronous'], dataframe['Asynchronous'])
        #ef_size = z_df / np.sqrt(self.nb_parti)        
        #ef_size_async = (df_sync['Embo_Score'].mean() - df_async['Embo_Score'].mean()) / df_async['Embo_Score'].std()
        #ef_size_sync = (df_sync['Embo_Score'].mean() - df_async['Embo_Score'].mean()) / df_sync['Embo_Score'].std()
        ef_size = (df_sync['Embo_Score'].mean() - df_async['Embo_Score'].mean()) / np.sqrt((df_sync['Embo_Score'].std()*df_sync['Embo_Score'].std() + df_async['Embo_Score'].std()*df_async['Embo_Score'].std())/2)
        return(ef_size)
    
    def wilcox_ef_size(self, dataframe):
        ef_size = rstatix.wilcox_effsize(data = dataframe, formula = Formula('Embo_Score ~ Condition'))
        return(ef_size)

    def conversion_R(self, dataframe):
        with localconverter(R.default_converter + pandas2ri.converter):
            df_r= R.conversion.py2rpy(dataframe)
        return(df_r)
    
    def conf_int(self, confidence):
        return()
