import argparse
from os import stat
import pandas as pd
import numpy as np

import scipy as sp

import statsmodels.api as sm
import statsmodels.formula.api as smf

np.random.seed(3516)

## Get methods from ##
from Between_test_class import *

parser = argparse.ArgumentParser(description='Between')
parser.add_argument('-p', help = 'participant number - exp number', nargs=2)
args = parser.parse_args() 

df_between = pd.read_csv('data_to_publish.csv')

exp = int(args.p[1])

parti = int(args.p[0])

stats = Between(parti, exp, df_between)

stats.__init__(parti, exp, df_between)

## Only for the between simulations ##
df_sync = stats.get_Condition(df_between, 'Synchronous')
df_async = stats.get_Condition(df_between, 'Asynchronous') 


## Sampling and testing the virtual dataset, then creating the log of the simulation ##
for i in range(1, exp):
    df_sync_simu = stats.sampling(df_sync, parti)
    df_async_simu = stats.sampling(df_async, parti)
    p_emb, conf_emb = stats.testing(df_sync_simu['Embo_Score'], df_async_simu['Embo_Score'])
    with localconverter(R.default_converter + pandas2ri.converter):
            df_r= R.conversion.py2rpy(pd.concat([df_sync_simu, df_async_simu], ignore_index=True))
    ef_size = stats.wilcox_ef_size(df_r)
    with localconverter(R.default_converter + pandas2ri.converter):
        ef_size_pd = R.conversion.rpy2py(ef_size)
    stats.writing_between(str(stats.nb_parti) + '_between_data_descriptions_' + str(stats.nb_exp) +'.csv', p_emb, conf_emb, ef_size_pd.iloc[0,3])


## For between simulation ##
name = str(parti) + '_between_data_descriptions' + '.csv'

## Read simulation log for a particular condition(within/between/2nd between) for a specific number of participants ##
df_count = pd.read_csv(name, names=["nb_simu", "nb_parti", "p_value", "confo", "effect_size"])

ef_size_moy = df_count.effect_size.mean()
fifth_perc = np.percentile(df_count['effect_size'], 5)
ninety_fifth_perc = np.percentile(df_count['effect_size'], 95)

count = 0

for i in range(0, exp-1):
    if (df_count.iat[i, 3] == True):
        count += 1
    
pourcent = count * 100 / exp


file_name = 'Pourcentage_Conforme_Between.csv'

with open(file_name, 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([exp, parti, pourcent, ef_size_moy, fifth_perc, ninety_fifth_perc])
