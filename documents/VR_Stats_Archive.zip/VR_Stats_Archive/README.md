This archive contains the files and data for the statistical analysis associated with the IEEE VR 2021 Conference paper "Within or Between? Comparing Experimental Designs for Virtual Embodiment Studies", authored by Grégoire Richard, Thomas Pietrzak, Ferran Argelaguet, Anatole Lécuyer, Géry Casiez.

It contains the following :
- 'data_to_publish.csv': the aggregated embodiment data gathered from the experiment, used in the different analyses.
- 'stat_analysis_paper_form.html': HTML output of the statistical analysis as presented in the paper.
- 'Pourcentage_Conforme_Between.csv'; 'Pourcentage_Conforme_Between_2nd.csv'; 'Pourcentage_Conforme_Within.csv' : data used to plot the graphs shown in the HTML output and in the paper. The data was obtained through simulations based on the embodiment data in 'data_to_publish.csv'.

We also provide the scripts that were used to obtain 'Pourcentage_Conforme_X.csv'.
- 'Between_test_class.py' and 'Stats_test_class.py' contain the different methods used for the simulations.
- 'simulation_code.py' provides the pipeline used to simulate virtual experiments with varying sample size for either a within-subjects or a between-subjects analysis.

Note that those scripts require the 'rstatix' and 'bootES' packages from R to calculate the effect size, and 'rpy2' to use R methods and packages inside the Python environment.
We ran the pipeline on Ubuntu, as 'rpy2' is not supported on Windows.

Finally, we provide the simulation logs that were obtained through the different simulation. The folders '2nd between', 'Between' and 'Within' contain logs for all sample sizes shown in the paper.
To rerun the simulations and get the logs (or produce some more), either run 'code_simu_between.py', 'code_simu_between_2_nd.py' or 'code_simu_within.py' by specifying the required sample size and number of virtual experiments.
An example is provided below:
python3 code_simu_within.py -p 35 100000
for 100.000 virtual experiments each sampling 35 participants out of the 92 participants original dataset.
